/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author matheus
 */
public class Lock {
    public void end(){
        System.out.println("end");
    }
    public void reset(){
        System.out.println("reset");
    }
}
